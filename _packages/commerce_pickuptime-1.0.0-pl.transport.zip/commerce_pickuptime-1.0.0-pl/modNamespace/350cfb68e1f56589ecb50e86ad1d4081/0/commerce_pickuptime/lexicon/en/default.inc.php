<?php

$_lang['commerce_pickuptime'] = 'PickupTime';
$_lang['commerce_pickuptime.description'] = 'Stores the customer-selected pickup time with the order and shipments.';
$_lang['commerce_pickuptime.pickup_at'] = 'Pick-up at [[+time]]';
$_lang['commerce.pickuptime'] = 'Pickup Time';
