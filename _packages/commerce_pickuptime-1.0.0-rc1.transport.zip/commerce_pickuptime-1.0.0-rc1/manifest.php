<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2018

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'PickupTime for Commerce
------------------------

Stores the customer-selected pickup time with the order and shipments.

You\'ll need to add a field with name "pickuptime" to your shipping template. Then the module stores the chosen pickup
time in the order properties (e.g. {{ order.properties.pickuptime }} will show it in most templates including emails),
and also into the tracking reference field of order shipments to make it visible in the order interface.
',
    'changelog' => '++ PickupTime for Commerce 0.1.0-pl
++ Released on
++++++++++++++++++++++++++
- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '0aea5a7e3f1877ccec7c12143ad10810',
      'native_key' => 'commerce_pickuptime',
      'filename' => 'modNamespace/feacd054c3cb327ea65b1b9ff5ee914a.vehicle',
    ),
  ),
);